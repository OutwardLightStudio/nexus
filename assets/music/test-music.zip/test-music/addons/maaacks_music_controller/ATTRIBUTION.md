# Attribution
## Collaborators

### Godot Music Controller
Author: [Marek Belski](https://github.com/Maaack/Godot-Music-Controller/graphs/contributors)  
Source: [github: Godot-Music-Controller](https://github.com/Maaack/Godot-Music-Controller)  
License: [MIT License](LICENSE.txt)  

## Tools
#### Godot
Author: [Juan Linietsky, Ariel Manzur, and contributors](https://godotengine.org/contact)  
Source: [godotengine.org](https://godotengine.org/)  
License: [MIT License](https://github.com/godotengine/godot/blob/master/LICENSE.txt) 

#### Git
Author: [Linus Torvalds](https://github.com/torvalds)  
Source: [git-scm.com](https://git-scm.com/downloads)  
License: [GNU General Public License version 2](https://opensource.org/licenses/GPL-2.0)